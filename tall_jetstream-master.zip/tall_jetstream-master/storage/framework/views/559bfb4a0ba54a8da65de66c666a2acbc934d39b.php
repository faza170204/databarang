<?php $attributes = $attributes->exceptProps(['sortBy', 'sortAsc', 'sortField']); ?>
<?php foreach (array_filter((['sortBy', 'sortAsc', 'sortField']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if( $sortBy == $sortField): ?>
    <?php if( !$sortAsc): ?>
        <span class="w-4 h-4 ml-2">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
            </svg>
        </span>
    <?php endif; ?>

    <?php if( $sortAsc): ?>
        <span class="w-4 h-4 ml-2">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd" />
            </svg>
        </span>
    <?php endif; ?>
<?php endif; ?>

<?php /**PATH C:\Users\MyBook Z Series\Downloads\Compressed\tall_jetstream-master\tall_jetstream-master\resources\views/components/sort-icon.blade.php ENDPATH**/ ?>