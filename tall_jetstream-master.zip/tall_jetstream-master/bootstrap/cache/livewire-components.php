<?php return array (
  'items' => 'App\\Http\\Livewire\\Items',
);